package com.bwa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import com.bwa.bean.Bank;

public class BankDAOImpl implements IBankDAO {

	Connection conn;
	Bank bank;

	public BankDAOImpl() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
		} catch (ClassNotFoundException | SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@Override
	public void addUserAccount(Bank bank) {
		try {

			PreparedStatement prepareStatement = conn
					.prepareStatement("insert into banking_wallet values(?,?,?,?,?,?,?)");
			prepareStatement.setInt(1, bank.getAcNo());
			prepareStatement.setString(2, bank.getName());
			prepareStatement.setString(3, bank.getDob());
			prepareStatement.setString(4, bank.getNumber());
			prepareStatement.setInt(5, bank.getPin());
			prepareStatement.setLong(6, bank.getBalance());
			prepareStatement.setString(7, bank.getTran());
			prepareStatement.execute();
		} catch (SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@Override
	public String getBalance(int accountNo) {
		try {
			PreparedStatement prepareStatement = conn
					.prepareStatement("select balance from banking_wallet where acno=?");
			prepareStatement.setInt(1, accountNo);
			ResultSet resultSet = prepareStatement.executeQuery();
			resultSet.next();
			long balance = resultSet.getLong("balance");
			return "Your Account with account-number " + accountNo + " has a balance of " + balance;
		} catch (SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
			return "Error";
		}

	}

	@Override
	public String depositMoney(int accountNumber, long amount, String tran) {
		try {
			PreparedStatement prepareStatement = conn
					.prepareStatement("update banking_wallet set balance = balance + ? where acno = ?");
			prepareStatement.setLong(1, amount);
//			prepareStatement.setString(2, tran);
			prepareStatement.setInt(2, accountNumber);
			prepareStatement.executeUpdate();
			prepareStatement = conn
					.prepareStatement("update banking_wallet set trans=concat(trans, ?) where acno=?");
			prepareStatement.setString(1, tran);
			prepareStatement.setInt(2, accountNumber);
			return "Money Added Successfully";
		} catch (SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
			return "Error";
		}
	}

	@Override
	public String withdrawMoney(int accountNumber, long amount, String tran) {
		try {
			PreparedStatement prepareStatement = conn
					.prepareStatement("update banking_wallet set balance = balance - ? where acno = ?");
			prepareStatement.setLong(1, amount);
//			prepareStatement.setString(2, tran);
			prepareStatement.setInt(2, accountNumber);
			prepareStatement.executeUpdate();
//			prepareStatement = conn
//					.prepareStatement("update banking_wallet set trans=concat(trans, ?) where acno=?");
//			prepareStatement.setString(1, tran);
//			prepareStatement.setInt(2, accountNumber);
			return "Money withdrawn Successfully";
		} catch (SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
			return "Error";
		}
	}
	
	@Override
	public String transferMoney(int accountNumber01, long amount01, int accountNumber02) {
		try {
			PreparedStatement prepareStatement = conn
					.prepareStatement("update banking_wallet set balance = balance - ? where acno = ?");
			prepareStatement.setLong(1, amount01);
			prepareStatement.setInt(2, accountNumber01);
			prepareStatement.executeUpdate();
		 prepareStatement = conn
					.prepareStatement("update banking_wallet set balance = balance + ? where acno = ?");
			prepareStatement.setLong(1, amount01);
			prepareStatement.setInt(2, accountNumber02);
			prepareStatement.executeUpdate();
			return "Money Transfered Successfully";
		} catch (SQLException ex) {
			Logger.getLogger(BankDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
			return "Error";
		}
		
	}

	@Override
	public String getTransaction(int accountNumber) {
	
		return null;
	}

	
}
