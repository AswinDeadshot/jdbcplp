package com.bwa.dao;

import com.bwa.bean.Bank;

public interface IBankDAO {

	public void addUserAccount(Bank bank);
	
	public String getBalance(int accountNo);
	
	public String depositMoney(int accountNumber,long amount,String tran);
	
	public String withdrawMoney(int accountNumber, long amount,String tran);
	
	public String getTransaction(int accountNumber);

	public String transferMoney(int accountNumber01, long amount01, int accountNumber02);


	
}
