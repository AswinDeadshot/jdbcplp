package com.bwa.service;

import java.sql.ResultSet;

import com.bwa.bean.Bank;
import com.bwa.dao.BankDAOImpl;
import com.bwa.dao.IBankDAO;

public class BankWalletServiceImpl implements IBankWalletService{

	IBankDAO bankDao=new BankDAOImpl();
	
	@Override
	public void addAccount(Bank bank) {
		bankDao.addUserAccount(bank);
		
	}

	@Override
	public String checkBalance(int accountNo) {
		return  bankDao.getBalance(accountNo);
	}

	@Override
	public String depositMoney(int accountNumber, long amount, String tran) {
		return  bankDao.depositMoney(accountNumber, amount, tran);
	}

	@Override
	public String withdrawMoney(int accountNumber, long amount, String tran) {
		return  bankDao.withdrawMoney(accountNumber, amount, tran);
	}


	@Override
	public String transferMoney(int accountNumber01, long amount01, int accountNumber02) {
		return bankDao.transferMoney(accountNumber01,amount01,accountNumber02);
	}

	@Override
	public String getTransactionDetails(int accountNumber) {
		return null;
	}
}
