package com.bwa.exception;

@SuppressWarnings("serial")

public class BankUserInputException extends Exception {

}
