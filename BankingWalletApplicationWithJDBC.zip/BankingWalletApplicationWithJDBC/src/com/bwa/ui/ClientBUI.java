package com.bwa.ui;

import java.util.Scanner;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;

import com.bwa.bean.Bank;
import com.bwa.service.BankWalletServiceImpl;
import com.bwa.service.IBankWalletService;

public class ClientBUI {
	
	
	public static void main(String args[])
	{
		Bank bank;
		ClientBUI clientBUI=new ClientBUI();
		IBankWalletService bankWalletService = new BankWalletServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int choice;
		while(true)
		{
		 	System.out.println("Welcome to xyz bank wallet");
            System.out.println("Choose any of these options from one to seven");
            System.out.println("1.Create an Account");
            System.out.println("2.Check your Balance");
            System.out.println("3.Deposit Money");
            System.out.println("4.Withdraw Money");
            System.out.println("5.Transfer Money");
            System.out.println("6.View Transaction");
            System.out.println("7.Exit");
            choice = scanner.nextInt();
            switch(choice)
            {
            case 1:
            	 System.out.println("ENTER YOUR NAME:");
                 String name=scanner.next();
                 System.out.println("ENTER YOUR DATE OF BIRTH IN DD/MM/YYYY");
                 String dob=scanner.next();
                 System.out.println("ENTER YOUR PHONE NUMBER ( MUST CONTAIN ONLY TEN DIGITS )");
                 String phno=scanner.next();
                 System.out.println("ENTER YOUR PIN(ONLY FOUR DIGITS)");
                 int pin=scanner.nextInt();
                 System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
                 long amt=scanner.nextLong();
                 LocalDate date=LocalDate.now();  
                 LocalTime time=LocalTime.now();
                 int acno = (int) ((Math.random())*100000);
                 bank=new Bank(acno,name,dob,phno,pin,amt,"\n Date : "+date+" Time : "+time+ "  Account created Successfully.");    
                 bankWalletService.addAccount(bank);
                 System.out.println("Your account creteed.\n Your Account number is "+acno);
                 break;
            case 2:
            	System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
            	int accountNumber=scanner.nextInt();
            	String message=bankWalletService.checkBalance(accountNumber);
             	System.out.println(message);
            	break;
            case 3:
            	System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
            	int accountNumber1=scanner.nextInt();
            	System.out.println("ENTER THE AMOUNT YOU NEED TO DEPOSIT : ");
            	long amount=scanner.nextLong();
            	String message1=bankWalletService.depositMoney(accountNumber1, amount, "\n Amount of RS."+amount+" was added to your account");
            	System.out.println(message1);
            	break;
            case 4:
            	System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
            	int accountNumberr=scanner.nextInt();
            	System.out.println("ENTER THE AMOUNT YOU NEED TO WITHDRAW : ");
            	long amountt=scanner.nextLong();
            	String messagee=bankWalletService.withdrawMoney(accountNumberr, amountt, "\n Amount of RS."+amountt+" was removed from your account");
            	System.out.println(messagee);
            	break;
            case 5:
            	System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
            	int accountNumber01=scanner.nextInt();
            	System.out.println("ENTER THE AMOUNT YOU NEED TO Send : ");
            	long amount01=scanner.nextLong();
            	System.out.println("ENTER ANOTHER ACCOUNT NUMBER : ");
            	int accountNumber02=scanner.nextInt();
            	String messages=bankWalletService.transferMoney(accountNumber01, amount01,accountNumber02);
            	System.out.println(messages);
            	break;
            case 6:
            	break;
            case 7:scanner.close();
            	break;
            default:
            	
            	
            }
		}
		
	}


	
}
