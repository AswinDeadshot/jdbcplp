/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankMain;

import bankHelper.BankHelper;
import bankService.BankService;

//import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class BankAddDetails {
     BankHelper bh;
     BankService bs;
   
//BankAddDetails bad=new BankAddDetails();
     Scanner sc=new Scanner(System.in);
     public BankAddDetails()
     {
         bs=new BankService();
        
     }
     
     public void addUserDetails()  // throws InputMismatchException
     {
         System.out.println("ENTER YOUR NAME:");
         String name=validateName(sc.next());
         System.out.println("ENTER YOUR DATE OF BIRTH IN DD/MM/YYYY");
         String date=sc.next();
         System.out.println("ENTER YOUR PHONE NUMBER ( MUST CONTAIN ONLY TEN DIGITS )");
         String pn= validateNumber(sc.next());
         System.out.println("ENTER YOUR SECURITY PIN ( ONLY 4 DIGIT NUMBERS )");
         int ps=validatePin(sc.nextInt());	 
         System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
         long d=sc.nextLong();
         bh=new BankHelper (name,date,pn,ps,d);
         bs.createAccount(bh); 
     }
     public void checkBalance()
     {
         System.out.println("Enter your ten didgit Account Number");
         double a=sc.nextDouble();
         bs.balanceCheck(a);
     }

    public void addMoney() 
    {
      System.out.println("Enter your ten didgit Account Number");
      double a=sc.nextDouble();
      bs.depositMoney(a);
    }

    public void removeMoney()
    {
       System.out.println("Enter your ten didgit Account Number");
       double a=sc.nextDouble();
       bs.withdrawMoney(a);
    }

    public void sendMoney() 
    {
          System.out.println("Enter your ten didgit Account Number");
         double a=sc.nextDouble();
         bs.transferMoney(a);
        
    }
    
    public void transactionDetails() {
    	 System.out.println("Enter your ten didgit Account Number");
    	 double s=sc.nextDouble();
    	// bs.transactionDetailsView(a);
    }
    
    
    
    

public String validateName(String nm)
{
	while(true) {

		if(Pattern.matches("([A-Z])*([a-z])*",nm))
		{
			return nm;
		}
		else {
			System.out.println("Name should only have alphabets!!!!\nEnter again");
			nm=sc.next();
		return nm;
	}
	}
}
        
public String validateNumber(String n)
    
    {
	while(true)
	{
    	  if(n.length()!=10)
    	  {
    	         System.out.println("You haven't entered the proper number!!!\n Please Enter Your Phone Number Again.");
    	          n=sc.next();
    	          return n;
    	  }  
    	  else
    	return n;
    }
    }

public int validatePin(int n)
    
    {
	  while(true)
	  {
	  String g=Integer.toString(n);
    	  if(g.length()!=4)
    	  {
    	         System.out.println("You haven't entered the proper PIN!!!\n Please Enter Your PIN Again.");
    	          n=sc.nextInt();
    	          return n;
    	  }
    	  else
		return n;  
	  }
    
    }



}
