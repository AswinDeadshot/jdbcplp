
package bankService;

import bankDAO.BankDAO;
import bankHelper.BankHelper;
import bankHelper.BankTransactionHelper;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
//import java.util.HashMap;
import java.util.Scanner;


public class BankService {
    double a;
    int tid=1122;
    BankDAO bd=new BankDAO();
    Scanner sc=new Scanner(System.in);
    BankHelper bh=new BankHelper();
    BankTransactionHelper bt=new BankTransactionHelper();
    String tr[]=new String [1000];
    int i=0;
    public void createAccount(BankHelper bh)
    {
     double b = Math.random()%100;
     double a = b*1457863;
     this.a =a;
      bd.addToMap(a, bh);
      String g="Initail 1000 added to "+a;
      bd.addToTransaction(g, a);
    }
    
    public void balanceCheck(double a)
    {
        if(bd.getHMValues().containsKey(a))
        {
            System.out.println("Enter your PIN:");
            int p=sc.nextInt();
            bh= (BankHelper) bd.getHMValues().get(a);
            int pas;
            pas=bh.getPin();
       
       if(p!=pas){
            System.out.println("invalid PIN");
       }
       else {
          System.out.println("Hello "+bh.getName());
          System.out.println("Your Account balance is "+bh.getBalance());
        }
        }
        else{
            System.out.println("Enter correct account number!!!!");
        }
    }

    public void depositMoney(double a) {
       if(bd.getHMValues().containsKey(a))
       {
           System.out.println("Enter your PIN:");
           int p=sc.nextInt();
           bh= (BankHelper) bd.getHMValues().get(a);
           int pas;
           pas=bh.getPin();
           
           if(p!=pas){
           System.out.println("invalid PIN");
             }
           else
           {
              System.out.println("Hello "+bh.getName());
               System.out.println("Enter the deposit amount");
               long dam=sc.nextLong();
               long d=bh.getBalance();
               d=dam+d;
               bh.setBalance(d);
               System.out.println("Your Account balance is "+bh.getBalance());
               String g="The Amount of "+dam+" was added to your account "+a;
               bd.addToTransaction(g, a);
           }
       }
       
       else{
            System.out.println("Enter correct account number!!!!");
       }
    }

    public void withdrawMoney(double a) {
         if(bd.getHMValues().containsKey(a))
         {
           System.out.println("Enter your PIN:");
           int p=sc.nextInt();
           bh= (BankHelper) bd.getHMValues().get(a);
           int pas;
           pas=bh.getPin();
       
           if(p!=pas){
           System.out.println("invalid PIN");
             }
           else
           {
              System.out.println("Hello "+bh.getName());
              System.out.println("Enter the amount you want to withdraw");
               long dam=sc.nextLong();
               long d=bh.getBalance();
               if(dam>d)
               {
                   System.out.println("Insufficient balance");
               }
               else{
               d=d-dam;
               bh.setBalance(d);
               System.out.println("you have withdrawn "+dam);
               System.out.println("Your Account balance is "+bh.getBalance());
               String g="The Amount of "+dam+" was withdrwan from your account "+a;
               bd.addToTransaction(g, a);
               
               } 
           }
         }
         else{
            System.out.println("Enter correct account number!!!!");
       }
         
    }

    public void transferMoney(double a) {
        if(bd.getHMValues().containsKey(a))
        {
           System.out.println("Enter your PIN:");
           int p=sc.nextInt();
           bh= (BankHelper) bd.getHMValues().get(a);
           int pas;
           pas=bh.getPin();
            if(p!=pas){
           System.out.println("invalid PIN");
             }
            else{
              System.out.println("Hello "+bh.getName());
              System.out.println("Enter the amount you want to send");
              long sa=sc.nextLong();
              long sac=bh.getBalance();
              if(sa>sac)
               {
                   System.out.println("Insufficient balance");
               }
              else{
                  sac=sac-sa;
                   bh.setBalance(sac);
                   
              }
              System.out.println("Enter the accountno to which you want to send money");
              double acno=sc.nextDouble();
               if(bd.getHMValues().containsKey(acno)){
              bh= (BankHelper) bd.getHMValues().get(acno);
              long ta=bh.getBalance();
              ta=ta+sa;
              bh.setBalance(ta);
              
              System.out.println("Money sent successfully");
              String g="The amount of "+sa+" was sent to "+acno;
              String l="The amount of "+sa+" was sent by "+a;
              bd.addToTransaction(g, a);
              bd.addToTransaction(l, acno);
           
               }
               
               else{
                   System.out.println("Invalid account number");
               }
               bh= (BankHelper) bd.getHMValues().get(a);
              System.out.println("Your account balance is "+bh.getBalance());
              
            }
            
        }
        else{
            System.out.println("Invalid account number");
        }
    }

	public void transactionDetailsView(double a) 
	
	{
		if(bd.getHTValues().containsValue(a))
		{
		System.out.println(getDetails(bd.getHTValues(),a));	
		}
		else
		{
			System.out.println("No account found");
		}
	}  
	
	
	public String getDetails(HashMap<String,Double> hm,double a)
	{
		String s="";
		
		for(String key:hm.keySet())
		{
			if(hm.get(key).equals(a))
			{
				s+=key+";";
			}
		}
		return s;
	}
	
	}
    
    

    
    
    
    
    
