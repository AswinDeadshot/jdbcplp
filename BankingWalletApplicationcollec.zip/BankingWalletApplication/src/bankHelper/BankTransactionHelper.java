package bankHelper;

public class BankTransactionHelper {
private int tid;
public int getTid() {
	return tid;
}

public void setTid(int tid) {
	this.tid = tid;
}

private int accNoFrom;
private int accNoTo;
private long amt;
private long balance;
private String type;
	
	


public int getAccNoFrom() {
	return accNoFrom;
}

public void setAccNoFrom(int accNoFrom) {
	this.accNoFrom = accNoFrom;
}

public int getAccNoTo() {
	return accNoTo;
}

public void setAccNoTo(int accNoTo) {
	this.accNoTo = accNoTo;
}

public long getAmt() {
	return amt;
}

public void setAmt(long amt) {
	this.amt = amt;
}

public long getBalance() {
	return balance;
}

public void setBalance(long balance) {
	this.balance = balance;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public BankTransactionHelper()
{
	
}

public BankTransactionHelper(int id,int accNoFrom,int accNoTo,long amt,long balance,String type)
{
	this.accNoFrom=accNoFrom;
	this.accNoTo=accNoTo;
	this.amt=amt;
	this.balance=balance;
	this.type=type;
}

@Override
public String toString() {
	return "BankTransactionHelper [tid=" + tid + ", accNoFrom=" + accNoFrom + ", accNoTo=" + accNoTo + ", amt=" + amt
			+ ", balance=" + balance + ", type=" + type + "]";
}


}
