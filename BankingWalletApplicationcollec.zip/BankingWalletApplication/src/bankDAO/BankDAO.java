/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankDAO;

import bankHelper.BankHelper;
import bankHelper.BankTransactionHelper;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Acer
 * 
 */
public class BankDAO {
   HashMap<Double,BankHelper> hm=new HashMap<Double,BankHelper>();
   HashMap<String,Double> ht=new HashMap<String,Double>();
   
   public void addToMap(double i,BankHelper bh)
   {
       hm.put(i, bh);
       System.out.println(hm);
   }
   public void addToTransaction(String bt,double a)
   {
	   ht.put(bt,a);
	   
   }
   public HashMap<Double,BankHelper> getHMValues()
   {
       return hm;
   }

public HashMap<String,Double> getHTValues()
 {
	return ht;      
   }



}

